import React, { useState } from 'react';
import { Navigation } from './Navigation';
import { Stepper } from './Stepper';
import { DocumentUpload } from './DocumentUpload';
import { HelpPanel } from './HelpPanel';

export const PageShell: React.FC = () => {
  const [hasFiles, setHasFiles] = useState(false);
  const [allValid, setAllValid] = useState(false);

  return (
    <>
      <Navigation />
      <div className="page">
        <Stepper hasFiles={hasFiles} allValid={allValid} currentStep="upload" />
        <main className="main-content">
          <DocumentUpload />
        </main>
        <HelpPanel />
      </div>
    </>
  );
};


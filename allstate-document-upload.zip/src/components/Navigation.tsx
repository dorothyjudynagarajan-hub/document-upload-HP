import React from 'react';

export const Navigation: React.FC = () => {
  return (
    <nav>
      <div className="nav-left">
        <div className="nav-logo">
          <div className="nav-logo-mark">A</div>
          Allstate
        </div>
        <div className="nav-links">
          <a href="#">Home</a>
          <a href="#">Protection ▾</a>
          <a href="#">Payments ▾</a>
          <a href="#">Claims</a>
          <a href="#">Settings ▾</a>
          <a href="#">Help</a>
        </div>
      </div>
      <div className="nav-right">
        <div className="nav-policy-badge">HOME 942041880</div>
        <div className="nav-logout">Log out</div>
      </div>
    </nav>
  );
};

import * as React from 'react';
import { EASING_FUNCTIONS } from '../utils';
import { LinkProps, TagProps } from './Basic';
declare const BREAKPOINTS: {
    medium: number;
    small: number;
    tiny: number;
};
type NavbarConfig = {
    animation: string;
    collapse: keyof typeof BREAKPOINTS;
    docHeight: boolean;
    duration: number;
    easing: keyof typeof EASING_FUNCTIONS;
    easing2: keyof typeof EASING_FUNCTIONS;
    noScroll: boolean;
};
export declare const NavbarContext: React.Context<NavbarConfig & {
    animDirect: -1 | 1;
    animOver: boolean;
    getBodyHeight: () => number | void;
    getOverlayHeight: () => number | undefined;
    isOpen: boolean;
    menu: React.MutableRefObject<HTMLElement | null>;
    root: React.MutableRefObject<HTMLElement | null>;
    toggleOpen: () => void;
    navbarMounted: boolean;
    setFocusedLink: React.Dispatch<React.SetStateAction<number>>;
}>;
type NavbarChildrenType = NavbarContainerProps | NavbarBrandProps | NavbarMenuProps | NavbarButtonProps;
type NavbarProps = {
    tag: React.ElementType;
    config: NavbarConfig;
    className?: string;
    children?: React.ReactElement<NavbarChildrenType>[] | React.ReactElement<NavbarChildrenType>;
};
export declare const NavbarWrapper: React.ForwardRefExoticComponent<NavbarProps & React.RefAttributes<HTMLElement>>;
type NavbarContainerProps = TagProps & {
    toggleOpen?: () => void;
    isOpen?: boolean;
    children: React.ReactNode;
};
export declare const NavbarContainer: React.ForwardRefExoticComponent<import("./Basic").ElementProps<keyof HTMLElementTagNameMap> & {
    tag?: React.ElementType;
    grid?: unknown;
} & {
    children?: React.ReactNode | undefined;
} & {
    toggleOpen?: () => void;
    isOpen?: boolean;
    children: React.ReactNode;
} & React.RefAttributes<HTMLElement>>;
type NavbarBrandProps = LinkProps;
export declare const NavbarBrand: React.ForwardRefExoticComponent<import("./Basic").ElementProps<"a"> & {
    options?: {
        href: string;
        target?: "_self" | "_blank";
        preload?: "none" | "prefetch" | "prerender";
    };
    className?: string;
    button?: boolean;
    block?: string;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<HTMLAnchorElement>>;
type NavbarMenuProps = React.PropsWithChildren<React.HTMLAttributes<HTMLElement> & {
    tag?: React.ElementType;
    isOpen?: boolean;
}>;
export declare const NavbarMenu: React.ForwardRefExoticComponent<React.HTMLAttributes<HTMLElement> & {
    tag?: React.ElementType;
    isOpen?: boolean;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<HTMLElement>>;
export declare const NavbarLink: React.ForwardRefExoticComponent<import("./Basic").ElementProps<"a"> & {
    options?: {
        href: string;
        target?: "_self" | "_blank";
        preload?: "none" | "prefetch" | "prerender";
    };
    className?: string;
    button?: boolean;
    block?: string;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<HTMLAnchorElement>>;
type NavbarButtonProps = React.PropsWithChildren<{
    tag?: React.ElementType;
    className?: string;
}>;
export declare const NavbarButton: React.ForwardRefExoticComponent<{
    tag?: React.ElementType;
    className?: string;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<HTMLElement>>;
export {};
